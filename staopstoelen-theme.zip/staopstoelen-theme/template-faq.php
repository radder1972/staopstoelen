<?php
/* Template Name: FAQ Template */
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Veelgestelde Vragen (FAQ) | staopstoelen.nl</title>
  <meta name="description" content="Vind antwoorden op veelgestelde vragen over sta-op stoelen vergoedingen (zorgverzekering/WMO), passing aan huis, garantie en ons revisieproces.">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo get_stylesheet_directory_uri(); ?>/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon-16x16.png">
  <link rel="manifest" href="<?php echo get_stylesheet_directory_uri(); ?>/site.webmanifest">
  <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css?v=1.0.51">
  <!-- Schema.org LocalBusiness Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "staopstoelen.nl",
    "image": "https://staopstoelen.nl/assets/showroom.jpg",
    "@id": "https://staopstoelen.nl/#localbusiness",
    "url": "https://staopstoelen.nl/",
    "telephone": "+31786314858",
    "email": "info@schippercompactwonen.nl",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Merwedestraat 239",
      "addressLocality": "Dordrecht",
      "postalCode": "3313 GT",
      "addressCountry": "NL"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 51.8184,
      "longitude": 4.6990
    },
    "openingHoursSpecification": [
      {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": [
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday"
        ],
        "opens": "10:00",
        "closes": "16:00"
      }
    ]
  }
  </script>
</head>
<body>

  <!-- Floating Contact Menu -->
  <div class="floating-contact-wrapper" id="floatingContactWrapper">
    <div class="floating-menu" id="floatingMenu">
      <a href="https://wa.me/31622232964" target="_blank" class="floating-menu-item floating-whatsapp" id="btnWhatsapp">
        <div>
          <span class="floating-menu-item-text">WhatsApp ons</span>
          <span class="floating-menu-item-desc">Direct antwoord</span>
        </div>
        <div class="icon">
          <svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
      </a>
      <a href="tel:+31786314858" class="floating-menu-item floating-phone" id="btnPhone">
        <div>
          <span class="floating-menu-item-text">Bellen</span>
          <span class="floating-menu-item-desc">Spreek een BewegingsTechnoloog</span>
        </div>
        <div class="icon">
          <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
      </a>
      <a href="<?php echo home_url('/afspraak-inplannen/'); ?>" class="floating-menu-item floating-chat" id="btnCalendarLink">
        <div>
          <span class="floating-menu-item-text">Plan Adviesgesprek</span>
          <span class="floating-menu-item-desc">Thuis of in showroom</span>
        </div>
        <div class="icon">
          <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="16" y1="2" x2="16" y2="6" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="8" y1="2" x2="8" y2="6" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><line x1="3" y1="10" x2="21" y2="10" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
      </a>
    </div>
    <button class="floating-btn floating-btn-main" id="btnFloatingMain" aria-label="Open contactopties">
      <svg viewBox="0 0 24 24"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
  </div>

  <!-- Navigation Bar -->
  <header class="navbar">
    <div class="container navbar-container">
      <!-- Beautiful Overlapping Liquid Waves behind the logo -->
      <svg class="logo-swoosh" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 200" preserveAspectRatio="none">
        <!-- Wave 1: Sky Blue -->
        <path d="M 0,90 Q 250,160 500,100 T 1000,110" fill="none" stroke="var(--color-sky)" stroke-width="8" stroke-linecap="round" opacity="0.6"></path>
        <!-- Wave 2: Terracotta Orange -->
        <path d="M 0,110 Q 250,70 500,120 T 1000,130" fill="none" stroke="var(--color-terracotta)" stroke-width="6" stroke-linecap="round" opacity="0.75"></path>
        <!-- Wave 3: Sage Green -->
        <path d="M 0,125 Q 250,170 500,115 T 1000,140" fill="none" stroke="var(--color-sage)" stroke-width="7" stroke-linecap="round" opacity="0.8"></path>
        <!-- Wave 4: Forest Green -->
        <path d="M 0,140 Q 250,100 500,145 T 1000,150" fill="none" stroke="var(--color-forest)" stroke-width="10" stroke-linecap="round" opacity="0.95"></path>
      </svg>
      <a href="<?php echo home_url('/'); ?>" class="nav-text-logo" id="navTextLogo">staopstoelen<span>.nl</span></a>
      <div class="navbar-top-right" id="navbarTopRight">
        <a href="tel:+31786314858" class="nav-top-contact-link">
          <svg style="width: 15px; height: 15px; stroke: var(--color-terracotta); fill: none;" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          078 - 631 4858
        </a>
        <a href="mailto:info@schippercompactwonen.nl" class="nav-top-contact-link">
          <svg style="width: 15px; height: 15px; stroke: var(--color-terracotta); fill: none;" viewBox="0 0 24 24" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
          info@schippercompactwonen.nl
        </a>
        <a href="<?php echo home_url('/afspraak-inplannen/'); ?>" class="btn btn-primary btn-nav-appointment" id="btnNavAppointment">Maak een afspraak</a>
      </div>
      <button class="menu-toggle" id="menuToggle" aria-label="Open menu">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-row-2">
        <nav class="nav-links" id="navLinks">
          <a href="<?php echo home_url('/sta-op-stoelen/'); ?>" id="linkGoedkopeStaopstoelen">Sta-op Stoelen</a>
          <a href="<?php echo home_url('/senioren-stoelen/'); ?>" id="linkSeniorenstoelen">Senioren Stoelen</a>
          <a href="<?php echo home_url('/keuzehulp/'); ?>" id="linkKeuzehulp">Keuzehulp</a>
          <a href="<?php echo home_url('/revisieproces/'); ?>" id="linkRevisie">Revisieproces</a>
          <a href="<?php echo home_url('/klantverhalen/'); ?>" id="linkKlantverhalen">Ervaringen</a>
          <a href="<?php echo home_url('/faq/'); ?>" class="active" id="linkFaq">FAQ</a>
          <a href="<?php echo home_url('/over-ons/'); ?>" id="linkOverOns">Over Ons</a>
          <a href="<?php echo home_url('/afspraak-inplannen/'); ?>" class="nav-desktop-hide" id="linkAfspraak">Afspraak Maken</a>
        </nav>
      </div>
    </div>
  </header>

  <!-- Banner Header -->
  <section class="occasions-header" style="text-align: left;">
    <div class="container banner-flex-container" style="justify-content: flex-start; align-items: flex-start;">
      <div style="text-align: left; max-width: 600px; flex: 1; min-width: 280px;">
        <span class="section-tag" style="color: var(--color-terracotta);">Veelgestelde Vragen</span>
        <h1 style="color: var(--color-light); margin: 4px 0 8px 0; font-size: 2.5rem;">FAQ & Antwoorden</h1>
        <p style="margin: 0; color: rgba(255, 255, 255, 0.85); font-size: 1.1rem;">Heeft u vragen over vergoedingen, passingen aan huis of garantie? Vind hier direct de antwoorden.</p>
      </div>
    </div>
  </section>

  <!-- Page Content / Accordion -->
  <section class="faq-section">
    <div class="container">
      <a href="<?php echo home_url('/'); ?>" class="back-link">← Terug naar Home</a>
      <h2 class="section-title" style="margin-top: 20px; margin-bottom: 30px; font-size: 1.85rem; border-bottom: 2px solid var(--color-sage); padding-bottom: 8px;">Veelgestelde Vragen</h2>

      <div class="faq-accordion">
        
        <!-- Question 1 -->
        <div class="faq-item">
          <button class="faq-question">
            Wat is een sta-op stoel en hoe werkt het?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Een sta-op stoel biedt hulp bij het opstaan door middel van een elektromotor. De stoel is comfortabel en eenvoudig te bedienen met een handbediening. 
            </p>
            <p>
              Wanneer u wilt opstaan, drukt u op de knop waardoor de stoel rustig omhoog gaat en naar voren kantelt. Hierdoor wordt u als het ware in een staande positie gebracht en kunt u makkelijk en veilig opstaan. Daarnaast biedt de stoel optimale zithulp en diverse lig- en ruststanden.
            </p>
          </div>
        </div>

        <!-- Question 2 -->
        <div class="faq-item">
          <button class="faq-question">
            Wat zijn de belangrijkste voordelen van een sta-op stoel?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Er zitten veel ergonomische en praktische voordelen aan het gebruik van een sta-op stoel:
            </p>
            <ul>
              <li><strong>Eenvoudig opstaan:</strong> U kunt zelfstandig opstaan zonder fysieke overbelasting.</li>
              <li><strong>Maatwerk passing:</strong> De stoel wordt volledig op uw lichaamsmaten (zithoogte, -diepte en armleggerhoogte) ingesteld.</li>
              <li><strong>Rust en ontspanning:</strong> U kunt comfortabel zitten, relaxen en eventueel heerlijk in de stoel slapen.</li>
              <li><strong>Drukvermindering:</strong> Het vermindert de druk op uw billen en rug, wat klachten voorkomt.</li>
              <li><strong>Betere vochtafvoer:</strong> In de ligstand/relaxstand bevordert het een goede vochtafvoer uit de benen.</li>
            </ul>
          </div>
        </div>

        <!-- Question 3 -->
        <div class="faq-item">
          <button class="faq-question">
            Waarom kiezen voor een gespecialiseerde winkel in plaats van een reguliere meubelzaak?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Een sta-op stoel is een ergonomisch hulpmiddel en geen standaard meubelstuk. Als een stoel niet perfect aansluit op uw lichaam, kan dit leiden tot rugklachten, een slechte bloedsomloop of moeite met opstaan. 
            </p>
            <p>
              Als erkend zitspecialist beschikken wij over diepgaande kennis van Bewegingstechnologie. Wij meten uw ideale zithoogte, zitdiepte en armleggerhoogte tot op de centimeter nauwkeurig op en stellen de stoel ter plekke voor u af. Daarnaast bieden wij 2 jaar volledige garantie en een eigen servicedienst aan huis, iets wat reguliere meubelwinkels vaak niet kunnen bieden.
            </p>
          </div>
        </div>

        <!-- Question 4 -->
        <div class="faq-item">
          <button class="faq-question">
            Kan ik bij u een sta-op stoel op maat laten maken?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Ja, zeker! U bent van harte welkom in onze showroom in Dordrecht om een sta-op stoel volledig op uw wensen en lichaamsmaten te laten afstemmen. Onze specialisten helpen u bij het uitkiezen van het juiste model, de stof- of ledersoort en de benodigde functionaliteiten. 
            </p>
            <p>
              Let op: onze showroom is gevestigd in hetzelfde pand als dat van <strong>Schipper Compact Wonen</strong> aan de Merwedestraat 239 in Dordrecht. U kunt eenvoudig telefonisch of via onze website een gratis adviesgesprek inplannen.
            </p>
          </div>
        </div>

        <!-- Question 5 -->
        <div class="faq-item">
          <button class="faq-question">
            Wat is het verschil tussen een 1-, 2- of 3-motorige sta-op stoel?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Het aantal motoren bepaalt hoe flexibel en onafhankelijk u de verschillende delen van de stoel kunt verstellen:
            </p>
            <p>
              <strong>1-motorig (Basis):</strong> De rugleuning en voetensteun zijn met elkaar verbonden. Als u de voetensteun omhoog doet, gaat de rugleuning automatisch mee naar achteren. U kunt deze niet afzonderlijk bedienen.
            </p>
            <p>
              <strong>2-motorig (Relax):</strong> U kunt de rugleuning en de voetensteun onafhankelijk van elkaar verstellen met twee aparte motoren. Dit geeft u veel meer vrijheid om uw ideale relaxpositie in te stellen.
            </p>
            <p>
              <strong>3-motorig (Premium):</strong> De rugleuning en voetensteun zijn onafhankelijk bedienbaar, en de stoel beschikt over een aparte kantelverstelling (tilt-functie). Hierdoor kunt u met een rechte rug/zithoek achterover kantelen naar een comfortabele 'hart-balans' of slaapstand. Omdat de belasting over drie motoren verdeeld is, hebben deze stoelen doorgaans ook een langere levensduur.
            </p>
          </div>
        </div>

        <!-- Question 4 -->
        <div class="faq-item">
          <button class="faq-question">
            Wat kost een sta-op stoel?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Omdat een goede sta-op stoel een hoogwaardig kwaliteitsproduct is dat op maat wordt afgesteld, variëren de prijzen. Gemiddeld liggen de prijzen tussen de € 400,- en € 4.000,-.
            </p>
            <p>
              Hoe meer functionaliteiten, motoren en specifieke aanpassingen u wenst, hoe hoger de prijs. Wij adviseren om niet zomaar voor een goedkope, standaard stoel te gaan; een verkeerd afgestelde stoel kan juist fysieke klachten veroorzaken. Met ons assortiment van zowel nieuwe A-merk stoelen als gereviseerde occasions is er echter altijd een passende oplossing voor elk budget.
            </p>
          </div>
        </div>

        <!-- Question 5 -->
        <div class="faq-item">
          <button class="faq-question">
            Wordt een sta-op stoel vergoed door de zorgverzekering of de WMO?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              In de meeste gevallen wordt een sta-op stoel niet (meer) vergoed vanuit de basisverzekering van uw zorgverzekeraar, omdat het gezien wordt als een algemeen gebruikelijk hulpmiddel.
            </p>
            <p>
              Wel zijn er mogelijkheden via de <strong>WMO (Wet maatschappelijke ondersteuning)</strong> van uw gemeente. Als u wegens een fysieke beperking niet meer zelfstandig kunt opstaan en thuis wilt blijven wonen, kunt u bij het WMO-loket van uw gemeente een aanvraag indienen. Indien dit wordt goedgekeurd, ontvangt u een persoonsgebonden budget (PGB) of wordt er een stoel in natura geleverd. Wij kunnen u ondersteunen bij het aanleveren van de benodigde zitspecificaties en offertes voor uw WMO-aanvraag.
            </p>
          </div>
        </div>

        <!-- Question 6 -->
        <div class="faq-item">
          <button class="faq-question">
            Is een sta-op stoel aftrekbaar voor de belasting?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              In de regel is een sta-op stoel helaas niet zomaar fiscaal aftrekbaar. De Belastingdienst ziet dit als een algemeen gebruikelijk hulpmiddel en niet als een specifiek medisch hulpmiddel dat uitsluitend door zieke of invalide personen wordt gebruikt.
            </p>
            <p>
              Er zijn echter uitzonderingen wanneer er sprake is van een specifieke, zware medische indicatie of chronische ziekte waarbij de stoel direct gekoppeld is aan de beperking. Wij adviseren u om bij twijfel altijd vooraf contact op te nemen met uw belastingadviseur of de Belastingdienst.
            </p>
          </div>
        </div>

        <!-- Question 7 -->
        <div class="faq-item">
          <button class="faq-question">
            Kan ik de showroom in Dordrecht bezoeken?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              U bent van harte welkom in onze showroom aan de Merwedestraat 239 in Dordrecht. Hier hebben we altijd een ruim assortiment nieuwe en gereviseerde modellen klaarstaan om te testen.
            </p>
            <p>
              Onze vaste openingstijden zijn <strong>dinsdag t/m vrijdag van 10:00 tot 16:00 uur</strong>. Wilt u buiten deze openingstijden of op zaterdag langskomen? Dat kan zeker! Neem contact met ons op om een afspraak te plannen, zodat we alle tijd hebben om u van deskundig zitadvies te voorzien.
            </p>
          </div>
        </div>

        <!-- Question 8 -->
        <div class="faq-item">
          <button class="faq-question">
            Wat houdt het revisieproces van een occasion in?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Bij staopstoelen.nl zijn we gespecialiseerd in het reviseren van A-merk stoelen (zoals Fitform en Doge). Elk ingekocht model ondergaat een streng revisieproces in onze eigen werkplaats:
            </p>
            <p>
              De motoren en elektronica worden technisch volledig gecontroleerd en waar nodig vernieuwd. De vulling (kussens) wordt geïnspecteerd en indien nodig vervangen om de juiste ergonomische steun te garanderen. Tot slot wordt de bekleding diep gereinigd en gedesinfecteerd, of compleet opnieuw bekleed met hoogwaardige stof of leer. De stoelen verlaten onze werkplaats in absolute nieuwstaat.
            </p>
          </div>
        </div>

        <!-- Question 9 -->
        <div class="faq-item">
          <button class="faq-question">
            Zit er garantie op de tweedehands sta-op stoelen?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Ja, absoluut! Omdat wij volledig achter de kwaliteit van onze gereviseerde occasions staan, leveren wij elke occasion standaard met <strong>2 jaar volledige garantie</strong> op zowel de motoren, de elektronica als het mechaniek.
            </p>
            <p>
              Mocht er onverhoopt iets niet goed werken, dan komt onze eigen servicedienst snel bij u thuis langs om het probleem kosteloos te verhelpen. U geniet dus van de zekerheid van een nieuwe stoel, maar voor een tweedehands prijs.
            </p>
          </div>
        </div>

        <!-- Question 10 -->
        <div class="faq-item">
          <button class="faq-question">
            Hoe werkt de gratis passing aan huis?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Bent u niet in de gelegenheid om onze showroom te bezoeken? Geen probleem! Wij komen geheel gratis en vrijblijvend bij u langs voor een passing aan huis in de regio Dordrecht, Rotterdam en omstreken.
            </p>
            <p>
              Onze adviseur neemt 3 verschillende modellen sta-op stoelen mee in onze bezorgbus. In uw eigen vertrouwde huiskamer kunt u de stoelen rustig uitproberen. De zitspecialist stelt de stoelen ter plekke op uw lichaamsmaat in, zodat u het verschil in zitcomfort direct zelf ervaart. U zit nergens aan vast: de passing is 100% vrijblijvend.
            </p>
          </div>
        </div>

        <!-- Question 11 -->
        <div class="faq-item">
          <button class="faq-question">
            Hoe snel wordt mijn stoel geleverd en afgesteld?
            <span class="faq-icon"></span>
          </button>
          <div class="faq-answer">
            <p>
              Wij bezorgen de stoel vakkundig bij u thuis met onze eigen bezorgbus. Omdat we direct uit voorraad leveren, kan de bezorging vaak al binnen enkele werkdagen plaatsvinden.
            </p>
            <p>
              Bij aflevering stelt onze bezorger (of bewegingstechnoloog) de stoel ter plekke exact in op uw lichaamsmaten (zithoogte, zitdiepte en armleggerhoogte). Ook krijgt u een duidelijke instructie over het gebruik van de handbediening. De stoel is pas klaar als u er perfect in zit en comfortabel kunt opstaan.
            </p>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- Footer Section -->
  <footer>
    <div class="container footer-grid">
      <div class="footer-col">
        <h3 style="color: var(--color-light);">staopstoelen.nl</h3>
        <p style="font-size: 0.9rem; color: rgba(255,255,255,0.6); margin-top: 16px; line-height: 1.6;">
          Specialist in premium gereviseerde A-merk sta-op stoelen op maat. Duurzaam, comfortabel en betaalbaar.
        </p>
      </div>
      <div class="footer-col">
        <h3>Snelle Links</h3>
        <ul style="margin-top: 16px;">
          <li><a href="<?php echo home_url('/sta-op-stoelen/'); ?>">Sta-op Stoelen</a></li>
          <li><a href="<?php echo home_url('/senioren-stoelen/'); ?>">Senioren Stoelen</a></li>
          <li><a href="<?php echo home_url('/keuzehulp/'); ?>">Keuzehulp Wizard</a></li>
          <li><a href="<?php echo home_url('/revisieproces/'); ?>">Revisieproces</a></li>
          <li><a href="<?php echo home_url('/klantverhalen/'); ?>">Klantverhalen</a></li>
          <li><a href="<?php echo home_url('/faq/'); ?>">Veelgestelde vragen (FAQ)</a></li>
          <li><a href="<?php echo home_url('/afspraak-inplannen/'); ?>">Afspraak Inplannen</a></li>
          <li><a href="<?php echo home_url('/over-ons/'); ?>">Over Ons</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h3>Contact & Showroom</h3>
        <p style="font-size: 0.9rem; color: rgba(255,255,255,0.6); margin-top: 16px; line-height: 1.6;">
          <strong>Showroom Dordrecht:</strong><br>
          Merwedestraat 239<br>
          3313 GT Dordrecht<br>
          <span style="display: block; margin-top: 8px; margin-bottom: 12px;">
            <a href="tel:+31786314858" style="color: inherit; text-decoration: none; display: inline-flex; align-items: center; margin-bottom: 6px;">
              <svg class="contact-icon" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              078 - 631 4858
            </a><br>
            <a href="mailto:info@schippercompactwonen.nl" style="color: inherit; text-decoration: none; display: inline-flex; align-items: center;">
              <svg class="contact-icon" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><polyline points="22,6 12,13 2,6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              info@schippercompactwonen.nl
            </a>
          </span>
          <strong>Openingstijden:</strong><br>
          Maandag: Op afspraak<br>
          Dinsdag t/m Vrijdag: 10:00 - 16:00<br>
          Zaterdag: Op afspraak<br>
          <br>
          <span style="display: block; line-height: 1.4; font-weight: bold;">
            Buiten onze openingstijden ontvangen óf bezoeken we u graag op afspraak.
          </span>
        </p>
      </div>
    </div>
    <div class="container footer-bottom">
      <div class="footer-copyright">
        &copy; 2026 staopstoelen.nl. Alle rechten voorbehouden.
      </div>
      <div style="font-size: 0.875rem; color: rgba(255,255,255,0.5);">
        Gerealiseerd door BewegingsTechnologen. | Versie 110
      </div>
    </div>
  </footer>

  <script src="<?php echo get_stylesheet_directory_uri(); ?>/app.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const questions = document.querySelectorAll(".faq-question");
      
      questions.forEach(q => {
        q.addEventListener("click", () => {
          const item = q.parentElement;
          const answer = q.nextElementSibling;
          const isActive = item.classList.contains("active");
          
          // Close all FAQ items
          document.querySelectorAll(".faq-item").forEach(el => {
            el.classList.remove("active");
            el.querySelector(".faq-answer").style.maxHeight = null;
          });
          
          // Toggle clicked item
          if (!isActive) {
            item.classList.add("active");
            answer.style.maxHeight = answer.scrollHeight + "px";
          }
        });
      });
    });
  </script>
</body>
</html>
